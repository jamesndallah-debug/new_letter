
import React, { useState, useRef, useEffect } from 'react';

interface DodgingButtonProps {
  label: string;
  onDodged: () => void;
  continuousJiggle?: boolean;
}

const BOING_SOUND_URL = 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3';

const DodgingButton: React.FC<DodgingButtonProps> = ({ label, onDodged, continuousJiggle = true }) => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isMoved, setIsMoved] = useState(false);
  const [isJiggling, setIsJiggling] = useState(false);
  const boingRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    boingRef.current = new Audio(BOING_SOUND_URL);
    if (boingRef.current) {
      boingRef.current.volume = 0.3;
    }
  }, []);

  const moveButton = () => {
    // Play the boing sound
    if (boingRef.current) {
      boingRef.current.currentTime = 0;
      boingRef.current.play().catch(() => {});
    }

    setIsJiggling(true);
    
    setTimeout(() => {
      const maxX = window.innerWidth - 150;
      const maxY = window.innerHeight - 100;
      
      const newX = Math.random() * maxX;
      const newY = Math.random() * maxY;
      
      setPosition({ x: newX, y: newY });
      setIsMoved(true);
      setIsJiggling(false);
      onDodged();
    }, 50);
  };

  return (
    <div 
      className={`transition-all duration-300 ${isMoved ? 'fixed z-50' : 'relative z-10'}`}
      style={isMoved ? { left: position.x, top: position.y } : {}}
      onMouseEnter={moveButton}
      onTouchStart={moveButton}
    >
      <button 
        className={`
          px-8 py-3 font-bold rounded-full shadow-lg border-2 transition-all duration-200
          ${isJiggling 
            ? 'bg-rose-100 text-rose-600 border-rose-300 animate-jiggle scale-95' 
            : continuousJiggle 
              ? 'bg-gray-100 text-gray-600 border-transparent animate-jiggle-subtle' 
              : 'bg-gray-100 text-gray-600 border-transparent'
          }
          hover:bg-rose-50 hover:text-rose-500 hover:border-rose-200
        `}
      >
        {label}
      </button>
    </div>
  );
};

export default DodgingButton;
