
import { GoogleGenAI, Type } from "@google/genai";
import { LoveNote } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLoveNote = async (name: string): Promise<LoveNote> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Generate an incredibly romantic, sweet, and poetic response for my girlfriend ${name} because she just said YES to being my Valentine. 
      The tone should be deeply emotional, sincere, and celebrate our future together.
      
      Requirements:
      1. A short 4-line poem that captures the magic of her saying yes.
      2. A warm romantic message of about 3-4 sentences.
      3. A famous, beautiful romantic quote (e.g., from classic literature or poetry).
      4. The author of that quote.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            poem: {
              type: Type.STRING,
              description: "A short 4-line romantic poem.",
            },
            message: {
              type: Type.STRING,
              description: "A warm, deeply romantic message of appreciation.",
            },
            quote: {
              type: Type.STRING,
              description: "A famous romantic quote.",
            },
            quoteAuthor: {
              type: Type.STRING,
              description: "The author of the romantic quote.",
            },
          },
          required: ["poem", "message", "quote", "quoteAuthor"],
        },
      },
    });

    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Error generating love note:", error);
    return {
      poem: "Roses are red, violets are blue,\nMy heart found its home,\nthe moment I found you.",
      message: `My dearest ${name}, saying yes to me is the greatest gift I could ever receive. You are my light, my joy, and my everything. I promise to cherish you today and every day that follows.`,
      quote: "Whatever our souls are made of, hers and mine are the same.",
      quoteAuthor: "Emily Brontë"
    };
  }
};
